package emlakcepte.model.enums;

public enum RealtyType {
	
	ACTIVE,
	PASSIVE,
	DELETED,
	IN_REVIEW

}
