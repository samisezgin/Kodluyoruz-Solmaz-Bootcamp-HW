# EmlakCepte WebAPI Projesi

"OpenAPI Yaml Files" klasörünün içerisindeki .yaml uzantılı dosyalar Postman'e direkt import edilebilir.