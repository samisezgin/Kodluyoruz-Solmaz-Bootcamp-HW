package com.emlakcepte.controller;

import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

class BannerControllerTest {

    @Test
    void create() {
    }

    @Test
    void getAll() {
    }
}