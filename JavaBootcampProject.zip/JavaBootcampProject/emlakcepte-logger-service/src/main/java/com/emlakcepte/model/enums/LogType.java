package com.emlakcepte.model.enums;

public enum LogType {
    DB_LOG,
    CONSOLE_LOG,
    FILE_LOG
}
