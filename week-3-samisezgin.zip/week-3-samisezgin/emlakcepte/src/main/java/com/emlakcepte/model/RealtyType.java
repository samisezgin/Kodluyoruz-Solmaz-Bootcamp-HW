package com.emlakcepte.model;

public enum RealtyType
{
	HOUSE, WORKPLACE
}
