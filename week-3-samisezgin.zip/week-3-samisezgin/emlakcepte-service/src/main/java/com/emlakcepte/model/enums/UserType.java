package com.emlakcepte.model.enums;

public enum UserType {
	
	INDIVIDUAL, CORPARETE

}
