package com.emlakcepte.model.enums;

public enum RealtyType {
	
	ACTIVE,
	PASSIVE,
	DELETED

}
