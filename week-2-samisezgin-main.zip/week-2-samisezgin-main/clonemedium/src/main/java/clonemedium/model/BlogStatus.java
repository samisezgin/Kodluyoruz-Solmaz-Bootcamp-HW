package clonemedium.model;

public enum BlogStatus
{
	DRAFT, PUBLISHED, DELETED
}
