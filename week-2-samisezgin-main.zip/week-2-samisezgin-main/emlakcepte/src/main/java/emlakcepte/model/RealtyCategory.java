package emlakcepte.model;

public enum RealtyCategory
{
RENT,SALE
}
