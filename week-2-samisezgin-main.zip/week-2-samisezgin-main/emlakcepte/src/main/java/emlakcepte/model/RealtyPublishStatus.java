package emlakcepte.model;

public enum RealtyPublishStatus {
	
	ACTIVE,
	PASSIVE,
	DELETED

}