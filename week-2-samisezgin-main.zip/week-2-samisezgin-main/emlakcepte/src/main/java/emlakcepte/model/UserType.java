package emlakcepte.model;

public enum UserType {
	
	INDIVIDUAL, CORPORATE

}